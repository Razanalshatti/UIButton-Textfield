//
//  ViewController.swift
//  UIBottunTextField
//
//  Created by Razan alshatti on 28/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    var profileImageView = UIImageView()
    let MyTextField = UITextField()
    let myButton = UIButton(type: .system)
   
    var selectedImage = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        view.addSubview(profileImageView)
        view.addSubview(MyTextField)
        view.addSubview(myButton)
        
        
        setupUI()
        AutoLayout()
        myButton.addTarget(self, action: #selector(saveButton), for: .touchUpInside)
    }
    
    func setupUI(){
        profileImageView.contentMode = .scaleToFill
        MyTextField.placeholder = "Type here..."
        myButton.setTitle("Submit ǃ ", for: .normal)
        
    }
    
    func AutoLayout(){
        
        myButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(100)
            make.height.equalTo(50)
            myButton.backgroundColor = .systemGray
            myButton.setTitleColor(.white, for: .normal)
            myButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
            myButton.layer.cornerRadius = 10
            myButton.layer.borderWidth = 1
            myButton.layer.borderColor = UIColor.black.cgColor
        }
        
        MyTextField.snp.makeConstraints { make in
            make.bottom.equalTo(myButton.snp.top).offset(-10)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            MyTextField.font = UIFont.systemFont(ofSize: 14)
            MyTextField.textColor = .darkGray
            MyTextField.textAlignment = .center
        
        }
        profileImageView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(250)
        }
        
        

        
    }
    
    @objc func saveButton(){
        selectedImage = MyTextField.text ?? ""
        profileImageView.image = UIImage(named: selectedImage)
    }
    
    


}

